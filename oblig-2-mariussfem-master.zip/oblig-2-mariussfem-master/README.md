# Oblig 2

OsloMet brukernavn: s362078

GitHub brukernavn: mariussfem

GitHub repo URL: https://github.com/DATA1700/oblig-2-mariussfem

URL til Heroku app: https://oblig-2-mariussfem.herokuapp.com/

Fullt navn: Marius Femsteinevik

Kort beskrivelse av applikasjon (5–10 setninger): 
Minimalt med styling, satt mest fokus på at den skal se ren ut.
Har lagt inn flere krav for input:
  Kan ikke legge inn ", ." og andre tegn i input for antall
  Tar ikke inn noe annet enn tall i input for telefonnummer
  Kan ikke la film stå på disabled choice "Velg film"

Har gjort antalgelser på at det ikke er noe maks antall på billetter, selv om det ville vært naturlig at en ikke kan bestille f.eks 100 billetter, men valgte å ikke legge det inn.
