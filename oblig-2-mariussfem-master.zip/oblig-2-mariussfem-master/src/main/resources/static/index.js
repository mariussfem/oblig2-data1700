$(() => {
    $("#addTickets").click(() => {
        const movie = $("#movie");
        const amount = $("#amount");
        const fName = $("#fName");
        const eName = $("#eName");
        const phoneNum = $("#phoneNum");
        const email = $("#email");

        const tickets = {
            movie: movie.val(),
            amount: amount.val(),
            fName: fName.val(),
            eName: eName.val(),
            phoneNum: phoneNum.val(),
            email: email.val()
        }

        if (inputval(tickets)) {
            $.post("/api", tickets, () => fetchTickets())
            movie.val("")
            amount.val("")
            fName.val("")
            eName.val("")
            phoneNum.val("")
            email.val("")

            $("#errorMovie").html("")
            $("#errorAmount").html("")
            $("#errorFName").html("")
            $("#errorEName").html("")
            $("#errorPhoneNum").html("")
            $("#errorEmail").html("")
        } else {
            console.log(null)
        }
    })

    $("#deleteTickets").click(() => $.get("/api"), () => deleteTickets())

})

const fetchTickets = () => $.post("/getApi", list => formatList(list))
const deleteTickets = () => $.get("/api", () => formatList(""))

const formatList = list => {
    let msg = "";

    if (list.length > 0) {
        msg += "<thead class='thead-dark'><tr><th scope=‘col’>Film</th><th scope=‘col’>Antall</th><th scope=‘col’>Navn</th><th scope=‘col’>Telefonnummer</th><th scope=‘col>E-post</th></tr></thead>"

        for (let tickets of list) {
            msg += `<tbody><tr><td>${tickets.movie}</td><td>${tickets.amount}</td><td>${tickets.fName} ${tickets.eName}</td><td>${tickets.phoneNum}</td><td>${tickets.email}</td></tr>`
        }
    }
    msg += "<tbody>"
    $("#out").html(msg)
}

const inputval = tickets => {
    $("#errorMovie").html("")
    $("#errorAmount").html("")
    $("#errorFName").html("")
    $("#errorEName").html("")
    $("#errorPhoneNum").html("")
    $("#errorEmail").html("")

    if (tickets.movie === null) {
        $("#errorMovie").html("Velg en film")
    }
    if (tickets.amount === "") {
        $("#errorAmount").html("Ugyldig antall")
    }
    if (tickets.fName === "") {
        $("#errorFName").html("Skriv inn navn")
    }
    if (tickets.eName === "") {
        $("#errorEName").html("Skriv inn navn")
    }
    if (tickets.phoneNum === "") {
        $("#errorPhoneNum").html("Skriv inn telefonnummer")
    }
    if (tickets.phoneNum != ""){
        if(isNaN(tickets.phoneNum)){
            $("#errorPhoneNum").html("Bruk kun tall")
            return false
        }
    }
    if (tickets.email === ""){
        $("#errorEmail").html("Skriv inn navn")
    }
    else return true;
}