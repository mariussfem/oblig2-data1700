package oslomet;

public class Tickets {
    private String movie;
    private String amount;
    private String fName;
    private String eName;
    private String phoneNum;
    private String email;

    public Tickets(String movie, String amount, String fName, String eName, String phoneNum, String email) {
        this.movie = movie;
        this.amount = amount;
        this.fName = fName;
        this.eName = eName;
        this.phoneNum = phoneNum;
        this.email = email;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
