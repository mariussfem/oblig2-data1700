package oslomet;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class TicketsRepo {
    private List<Tickets> list = new ArrayList<>();

    public List<Tickets> addTickets(Tickets tickets){
        list.add(tickets);
        return list;
    }

    public List<Tickets> getTickets(){
        return list;
    }
    public void deleteTickets(){
        list.clear();
    }
}
