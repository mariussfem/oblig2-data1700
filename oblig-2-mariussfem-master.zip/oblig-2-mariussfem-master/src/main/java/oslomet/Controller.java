package oslomet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class Controller {

    @Autowired
    TicketsRepo repo;

    @PostMapping("/api")
    public void addTickets(Tickets tickets){
        repo.addTickets(tickets);
    }

    @PostMapping("/getApi")
    public List<Tickets> getTickets(){
        return repo.getTickets();
    }

    @GetMapping("/api")
    public void deleteTickets(){
        repo.deleteTickets();
    }
}