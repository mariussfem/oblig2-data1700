package oslomet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oblig2Application {

    public static void main(String[] args) {
        SpringApplication.run(Oblig2Application.class, args);
    }

}
